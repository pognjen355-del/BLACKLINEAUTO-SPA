# Blackline Auto Spa

Statički sajt, spreman za GitHub Pages.

## Objavljivanje

1. Napravi novi repozitorijum na GitHubu (npr. `blackline-auto-spa`).
2. Ubaci sve iz ovog foldera u koren repozitorijuma (`index.html`, folder `images`, `.nojekyll`).
3. Na GitHubu: Settings > Pages > Source: "Deploy from a branch", Branch: `main`, folder `/ (root)`, Save.
4. Posle minut-dva sajt je na `https://TVOJE-IME.github.io/blackline-auto-spa/`.

## Pre objave popuni

U `index.html` potraži i zameni: `[TELEFON]`, `[EMAIL]`, `[ADRESA]`, `[GRAD]`, `[RADNO VREME]`, `[TRAJNOST]`, i linkove za Instagram, TikTok i YouTube (`href="#kontakt"`).

Forma za rezervaciju trenutno ne šalje podatke (GitHub Pages nema server). Za slanje na mejl može se povezati besplatan servis kao Formspree.
